# HDMovie2 Android App
**WebView app for https://newhdmovie2.pro — works on Android Phone & Android TV**

---

## 📁 Project Structure

```
HDMovie2App/
├── build.gradle                          ← root Gradle config
├── settings.gradle
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle                      ← app dependencies
    └── src/main/
        ├── AndroidManifest.xml           ← permissions + activities
        ├── java/com/hdmovie2/app/
        │   ├── SplashActivity.java       ← branded splash screen
        │   ├── MainActivity.java         ← Phone/Tablet WebView
        │   └── TvActivity.java           ← Android TV WebView
        └── res/
            ├── layout/
            │   ├── activity_splash.xml
            │   ├── activity_main.xml
            │   └── activity_tv.xml
            ├── values/
            │   ├── colors.xml
            │   ├── strings.xml
            │   └── themes.xml
            ├── drawable/
            │   ├── btn_retry_bg.xml
            │   └── tv_banner.xml         ← replace with 320×180 PNG
            ├── mipmap-hdpi/
            │   └── ic_launcher.xml       ← replace with your icon PNG
            └── xml/
                ├── network_security_config.xml
                └── file_paths.xml
```

---

## ⚙️ Requirements

| Tool | Version |
|------|---------|
| Android Studio | Hedgehog 2023.1+ (or Iguana 2023.2+) |
| JDK | 17 (bundled with Android Studio) |
| Android SDK | API 34 (Android 14) |
| Gradle | 8.4 (auto-downloaded by wrapper) |
| AGP | 8.2.2 |

---

## 🚀 Build & Run

### Step 1 — Open in Android Studio
1. Open **Android Studio**
2. Click **File → Open** and select the `HDMovie2App` folder
3. Wait for Gradle sync to complete (downloads dependencies automatically)

### Step 2 — Add App Icon (optional but recommended)
Replace the placeholder icons:
- `res/mipmap-hdpi/ic_launcher.png` → 72×72px PNG
- `res/mipmap-xhdpi/ic_launcher.png` → 96×96px PNG
- `res/mipmap-xxhdpi/ic_launcher.png` → 144×144px PNG
- `res/mipmap-xxxhdpi/ic_launcher.png` → 192×192px PNG

Use **Android Studio → File → New → Image Asset** to generate all sizes automatically.

### Step 3 — TV Banner (Android TV only)
Replace `res/drawable/tv_banner.xml` with a **320×180dp PNG** named `tv_banner.png`.
This appears on the Android TV home screen row.

### Step 4 — Run on Phone
1. Connect your Android phone via USB (enable Developer Options + USB debugging)
2. Select your device in the toolbar
3. Click ▶ Run

### Step 5 — Run on Android TV
1. Enable **Developer Options** on the TV (Settings → About → click Build 7 times)
2. Enable **Network Debugging**: Settings → Developer Options → ADB over network
3. In Android Studio terminal:
   ```bash
   adb connect <TV_IP_ADDRESS>:5555
   ```
4. Select the TV from the device dropdown and click ▶ Run

### Step 6 — Build APK
```
Build → Build Bundle(s)/APK(s) → Build APK(s)
```
APK saved at: `app/build/outputs/apk/debug/app-debug.apk`

Transfer to phone via USB and install (allow "Install from unknown sources").

---

## 📱 Features

### Phone / Tablet
| Feature | Details |
|---------|---------|
| WebView | Full-featured with JS, cookies, DOM storage |
| Swipe to Refresh | Pull down to reload page |
| Smart Downloads | Uses Android DownloadManager, saves to Downloads folder |
| Back Navigation | Back button navigates within the site |
| No-Internet Screen | Friendly error with retry button |
| Ad Overlay Removal | CSS injection hides popup overlays |
| User Agent | Chrome Mobile UA for best site compatibility |

### Android TV
| Feature | Details |
|---------|---------|
| Fullscreen Layout | No status bar, full 1080p canvas |
| D-pad Navigation | UP/DOWN/LEFT/RIGHT scrolls the page |
| Media Keys | Play/Pause, Stop, FF (+10s), Rewind (-10s) |
| Focus Ring | Red outline shows which element is focused |
| Large Text | 130% text zoom for 10-ft viewing |
| Desktop UA | Full desktop site rendered on TV |
| TV Banner | Shown on Android TV home screen |

---

## 🔐 Permissions Explained

| Permission | Why |
|-----------|-----|
| `INTERNET` | Load the website |
| `ACCESS_NETWORK_STATE` | Detect offline state |
| `WRITE_EXTERNAL_STORAGE` | Save downloaded files (Android ≤ 9) |
| `READ_EXTERNAL_STORAGE` | Read files (Android ≤ 12) |

---

## 🛠️ Customization

### Change target URL
Edit in both `MainActivity.java` and `TvActivity.java`:
```java
private static final String TARGET_URL = "https://newhdmovie2.pro";
```

### Change app name
Edit `res/values/strings.xml`:
```xml
<string name="app_name">HDMovie2</string>
```

### Change accent color
Edit `res/values/colors.xml`:
```xml
<color name="accent_red">#E50914</color>
```

### Block external links on TV
In `TvActivity.java`, add a `shouldOverrideUrlLoading` in the WebViewClient (same pattern as MainActivity).

---

## 📦 Signing for Release (Play Store / Sideload)

```bash
# In Android Studio:
Build → Generate Signed Bundle / APK → APK
```
Or via command line:
```bash
./gradlew assembleRelease
```

---

## 🐛 Troubleshooting

| Issue | Fix |
|-------|-----|
| White screen on load | Check internet; clear app data |
| Videos not playing | Ensure `setMediaPlaybackRequiresUserGesture(false)` is set |
| Download not starting | Grant storage permission manually in Settings |
| TV remote not working | Ensure focus is on WebView; press OK/Enter first |
| ADB not connecting to TV | Make sure phone and TV are on same Wi-Fi |
