package com.hdmovie2.app;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.FragmentActivity;

/**
 * TvActivity — launched by the Leanback launcher on Android TV.
 *
 * Features:
 *  - Full-screen landscape WebView
 *  - D-pad / remote navigation injected via JavaScript
 *  - Larger font scaling for 10-ft UI
 *  - Retry screen on no internet
 */
public class TvActivity extends FragmentActivity {

    private static final String TARGET_URL = "https://newhdmovie2.pro";

    private WebView webView;
    private ProgressBar progressBar;
    private RelativeLayout noInternetLayout;

    // JavaScript for D-pad scrolling and focus navigation on TV
    private static final String TV_DPAD_JS =
        "javascript:(function(){" +
        "  document.addEventListener('keydown', function(e){" +
        "    var step = 200;" +
        "    if(e.keyCode===38){ window.scrollBy(0,-step); e.preventDefault(); }" +  // UP
        "    if(e.keyCode===40){ window.scrollBy(0, step); e.preventDefault(); }" +  // DOWN
        "    if(e.keyCode===37){ window.scrollBy(-step,0); e.preventDefault(); }" +  // LEFT
        "    if(e.keyCode===39){ window.scrollBy( step,0); e.preventDefault(); }" +  // RIGHT
        "  });" +
        "  // Make all links focusable" +
        "  var links = document.querySelectorAll('a, button, input, select');" +
        "  links.forEach(function(el){ el.setAttribute('tabindex','0'); });" +
        "})();";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tv);

        webView = findViewById(R.id.tv_webview);
        progressBar = findViewById(R.id.tv_progress_bar);
        noInternetLayout = findViewById(R.id.tv_no_internet_layout);
        TextView retryBtn = findViewById(R.id.tv_btn_retry);

        // ── WebView Settings (TV-optimised) ───────────────────
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setTextZoom(130); // Larger text for TV (10-ft UI)
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setBuiltInZoomControls(false);

        // Desktop UA so site renders full layout on TV
        settings.setUserAgentString(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        );

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        // Enable hardware acceleration
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        // ── WebViewClient ────────────────────────────────────
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                progressBar.setVisibility(View.VISIBLE);
                noInternetLayout.setVisibility(View.GONE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
                // Inject D-pad and TV CSS
                webView.loadUrl(TV_DPAD_JS);
                injectTvCSS(view);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request,
                                        WebResourceError error) {
                if (request.isForMainFrame()) {
                    progressBar.setVisibility(View.GONE);
                    noInternetLayout.setVisibility(View.VISIBLE);
                }
            }
        });

        // ── WebChromeClient ──────────────────────────────────
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
            }
        });

        // ── Retry Button ─────────────────────────────────────
        retryBtn.setOnClickListener(v -> {
            if (isNetworkAvailable()) {
                noInternetLayout.setVisibility(View.GONE);
                webView.reload();
            } else {
                Toast.makeText(TvActivity.this, "No internet connection", Toast.LENGTH_SHORT).show();
            }
        });

        // ── Load ─────────────────────────────────────────────
        if (isNetworkAvailable()) {
            webView.loadUrl(TARGET_URL);
        } else {
            noInternetLayout.setVisibility(View.VISIBLE);
        }
    }

    private void injectTvCSS(WebView view) {
        String css = "javascript:(function(){" +
            "var s=document.createElement('style');" +
            "s.type='text/css';" +
            "s.innerHTML='" +
            // Focus highlight for D-pad navigation
            "  *:focus { outline: 4px solid #e50914 !important; outline-offset: 2px !important; }" +
            "  a:focus, button:focus { background: rgba(229,9,20,0.15) !important; }" +
            // Scale up UI for TV
            "  body { font-size: 18px !important; }" +
            "  .popup, .ad-popup, [class*=popup], [id*=popup] { display:none !important; }" +
            "  img { max-width: 100% !important; }" +
            "';" +
            "document.head.appendChild(s);" +
            "})()";
        view.loadUrl(css);
    }

    // ── TV Remote / D-pad key handling ───────────────────────
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
                // Forward all D-pad events to WebView
                webView.dispatchKeyEvent(event);
                return true;

            case KeyEvent.KEYCODE_BACK:
                if (webView.canGoBack()) {
                    webView.goBack();
                    return true;
                }
                break;

            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_PLAY:
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                // Toggle playback via JS
                webView.loadUrl("javascript: " +
                    "(function(){ var v=document.querySelector('video');" +
                    "if(v){ v.paused ? v.play() : v.pause(); } })()");
                return true;

            case KeyEvent.KEYCODE_MEDIA_STOP:
                webView.loadUrl("javascript: " +
                    "(function(){ var v=document.querySelector('video');" +
                    "if(v){ v.pause(); v.currentTime=0; } })()");
                return true;

            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
                webView.loadUrl("javascript: " +
                    "(function(){ var v=document.querySelector('video');" +
                    "if(v){ v.currentTime+=10; } })()");
                return true;

            case KeyEvent.KEYCODE_MEDIA_REWIND:
                webView.loadUrl("javascript: " +
                    "(function(){ var v=document.querySelector('video');" +
                    "if(v){ v.currentTime-=10; } })()");
                return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager)
            getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo info = cm.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        webView.destroy();
    }
}
